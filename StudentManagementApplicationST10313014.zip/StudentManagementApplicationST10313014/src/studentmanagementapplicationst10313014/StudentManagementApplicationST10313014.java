/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentmanagementapplicationst10313014;

import java.util.Scanner;

/**
 *
 * @author joshu
 */
public class StudentManagementApplicationST10313014 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Student student = new Student();  
     Scanner POP = new Scanner(System.in);
     Scanner JdW = new Scanner(System.in);
     Scanner jdW = new Scanner(System.in);
     Scanner searchID = new Scanner(System.in);
     Scanner DeleteStudent = new Scanner(System.in);
     boolean closeProgram = false;
     int menuChoice = 0;
     int EntranceNum = 0;
     String Welcome = "STUDENT MANAGEMENT APPLICATION\n***************************************\n"
                + "Enter (1) to launch menu or any other key to exit";
     String menuName = "Please select one of the following menu items:\n"
               + "\n(1) - Capture a new student"
               + "\n(2) - Search for a student"
               + "\n(3) - Delete a student"
               + "\n(4) - Print student report"
               + "\n(5) - Exit Application";
     String falseOption = "Please enter a valid option";
     
        System.out.println(Welcome);
        EntranceNum = Integer.parseInt(POP.nextLine());
     if(EntranceNum == 1){
        while (!closeProgram){
            System.out.println(menuName);
            try{
                menuChoice = Integer.parseInt(JdW.nextLine()); // Read user input as an integer
                // Switch to choose a valid option
            switch (menuChoice){
               case 1 : student.SaveStudent(jdW) ; break;
               case 2 : student.SearchStudent(searchID) ; break;
               case 3 : student.DeleteStudent(DeleteStudent) ; break;
               case 4 : student.StudentReport() ; break;
               case 5 : closeProgram = student.ExitStudentApplication() ; break;
               default : System.out.println(falseOption); break;
               }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid option");
            }
    }jdW.close();JdW.close();
        }else {
            closeProgram = student.ExitStudentApplication();
        }
    }
}