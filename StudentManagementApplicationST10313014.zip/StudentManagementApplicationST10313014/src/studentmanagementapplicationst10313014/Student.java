/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementapplicationst10313014;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/*
This program was written by Joshua de Wet ST10313014
*/

public class Student{
    private List<Integer> stID = new ArrayList<>();
    private List<String> stName = new ArrayList<>();
    private List<Integer> stAge = new ArrayList<>();
    private List<String> stEmail = new ArrayList<>();
    private List<String> stCourse = new ArrayList<>();
    
     Scanner JdW = new Scanner(System.in);
    
    public void SaveStudent(Scanner jdW)
    {
        System.out.println("CAPTURE A NEW STUDENT\n"
                + "*************************");
        System.out.print("Enter student ID: ");
        int id = jdW.nextInt();
        jdW.nextLine();
        System.out.print("Enter student name: ");
        String name = jdW.nextLine();
        int age; // Declare age variable outside of the try-catch block

        while (true) {
            try {
                System.out.print("Enter student age: ");
                age = Integer.parseInt(jdW.nextLine());
                    if (age >= 16) {
                    break; // Age is valid, exit the loop
                } else {
                System.out.println("Please enter a correct age (>= 16)!!!");
                }
            } catch (NumberFormatException e) {
            System.out.println("Please enter a valid age as a number!!!");
            }
        }
        System.out.print("Enter student email: ");
        String email = jdW.nextLine();
        System.out.print("Enter student course: ");
        String course = jdW.nextLine();

        stID.add(id);
        stName.add(name);
        stAge.add(age);
        stEmail.add(email);
        stCourse.add(course);
        System.out.println("\n\nStudent information saved sucessfully\n\n");
    }
    //getters
    public List<Integer> getStID() {
        return stID;
    }
    public List<String> getStName() {
        return stName;
    }
    public List<Integer> getStAge() {
        return stAge;
    }
    public List<String> getStEmail() {
        return stEmail;
    }
    public List<String> getStCourse() {
        return stCourse;
    }
    public void setStCourse(List<String> stCourse) {
        this.stCourse = stCourse;
    }
    public Scanner getJdW() {
        return JdW;
    }
    public void setJdW(Scanner JdW) {
        this.JdW = JdW;
    }
    public void SearchStudent(Scanner searchID)
    {
        System.out.println("Enter the student id to search: ");
        int st = searchID.nextInt();
        
        for (int i = 0; i < stID.size(); i++) {
            if (stID.get(i) == st) {
                System.out.println("Student ID: " + stID.get(i));
                System.out.println("Student Name: " + stName.get(i));
                System.out.println("Student Age: " + stAge.get(i));
                System.out.println("Student Email: " + stEmail.get(i));
                System.out.println("Student Course: " + stCourse.get(i));
                System.out.println("\n\n");
                return; // Exit the method after displaying student information
            }
        }
        System.out.println("\nStudent with ID " + st + " not found.\n"
                + "\nPlease enter a valid ID!\n\n");
    }
    public void DeleteStudent(Scanner DeleteStudent)
    {
        System.out.println("Enter the student id to delete: ");
        int IDdelete = DeleteStudent.nextInt();
        for (int i = 0; i < stID.size(); i++) {
            if (stID.get(i) == IDdelete) {
                stID.remove(i);
                stName.remove(i);
                stAge.remove(i);
                stEmail.remove(i);
                stCourse.remove(i);
                System.out.println("\n\nStudent with ID " + IDdelete + " deleted.\n\n");
                return; // Exit the method after deleting the student
            }
        }
        System.out.println("\nStudent with ID " + IDdelete + " not found."
                + "\nPlease enter a valid ID!\n\n");
    }
    public void StudentReport()
    {
        for (int i = 0; i < stID.size(); i++) {
                System.out.println("Student: " + (i+1) );
                System.out.println("Student ID: " + stID.get(i));
                System.out.println("Student Name: " + stName.get(i));
                System.out.println("Student Age: " + stAge.get(i));
                System.out.println("Student Email: " + stEmail.get(i));
                System.out.println("Student Course: " + stCourse.get(i));
                System.out.println("\n");
            
        }
    }
    public boolean ExitStudentApplication()
    {
        System.out.println("Exiting Application...");
        return true;
    }
}
