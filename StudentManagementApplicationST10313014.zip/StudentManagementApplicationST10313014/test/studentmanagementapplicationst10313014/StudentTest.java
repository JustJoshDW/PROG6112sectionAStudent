/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package studentmanagementapplicationst10313014;

import java.io.ByteArrayOutputStream;
import org.junit.Test;
import java.util.Scanner;
import static org.junit.Assert.*;

/**
 *
 * @author joshu
 */
public class StudentTest {
    
//    public StudentTest() {
//    }
    @Test
    public void testSaveStudent() {
        Student st = new Student ();
        Scanner sn = new Scanner ("123\nJohn\n18\njohn@john.com\nprog\n");
        st.SaveStudent(sn );
        assertEquals(1, st.getStID().size());
        assertEquals(1, st.getStName().size());
        assertEquals(1, st.getStAge().size());
        assertEquals(1, st.getStEmail().size());
        assertEquals(1, st.getStCourse().size());
    }
    @Test
    public void testSearchStudent() {
        
        Student st = new Student ();
        Scanner sn = new Scanner ("123\nJohn\n18\njohn@john.com\nprog\n");
        st.SaveStudent(sn );
        Scanner sp = new Scanner("123\n");
        st.SearchStudent(sp);
       assertEquals(1, st.getStID().size());
        assertEquals(1, st.getStName().size());
        assertEquals(1, st.getStAge().size());
        assertEquals(1, st.getStEmail().size());
        assertEquals(1, st.getStCourse().size());
    }
    
    
    @Test
    public void testSearchStudent_StudentNotFound() {
        Student st = new Student ();
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        Scanner sn = new Scanner ("123\nJohn\n18\njohn@john.com\nprog\n");
        st.SaveStudent(sn );
        String expectedMessage = "";
        Scanner sp = new Scanner("124\n");      
        st.SearchStudent(sp);
        assertEquals(expectedMessage, outputStream.toString());
    }
    @Test
    public void testDeleteStudent() {
        Student st = new Student ();
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        Scanner sn = new Scanner ("123\nJohn\n18\njohn@john.com\nprog\n");
        st.SaveStudent(sn);
        String expectedMessage = "";
        Scanner sp = new Scanner("123\n"); 
        st.DeleteStudent(sp);
        Scanner sfd = new Scanner("123\n"); 
        st.SearchStudent(sfd);
        assertEquals(expectedMessage, outputStream.toString());
    }
    @Test
    public void testDeleteStudent_StudentNotFound() {
        Student st = new Student ();
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        Scanner sn = new Scanner ("123\nJohn\n18\njohn@john.com\nprog\n");
        st.SaveStudent(sn);
        String expectedMessage = "";
        Scanner sp = new Scanner("124\n"); 
        st.DeleteStudent(sp);
        Scanner sfd = new Scanner("123\n"); 
        st.SearchStudent(sfd);
       assertEquals(1, st.getStID().size());
        assertEquals(1, st.getStName().size());
        assertEquals(1, st.getStAge().size());
        assertEquals(1, st.getStEmail().size());
        assertEquals(1, st.getStCourse().size());
    }
}
